<script setup lang="ts"></script>
<template>
  <header
    class="sticky top-0 z-10 w-full flex justify-between bg-white p-4 text-base font-semibold color-lightBlue shadow"
  >
    <div>ONNX Runtime Web 部署图像分类模型</div>
    <div></div>
  </header>
</template>
<style lang="scss" scoped></style>
